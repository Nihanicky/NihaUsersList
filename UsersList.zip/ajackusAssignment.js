let usersListContainerEl = document.getElementById('usersListContainer');
let addButtonEl = document.getElementById("addButton");
let url = 'https://jsonplaceholder.typicode.com/users';

function onDeleteUser(userId) {
    let userElement = document.getElementById(userId);
    usersListContainerEl.removeChild(userElement);
    let options = {
        method: "DELETE",
        headers: {
            "Content-Type": "application/json",
            Accept: "application/json",
            Authorization: "Bearer 572fc4bb533c9fb6f1424172bd24c44104c626b8523881750ae86558d6d29817"
        }
    };
    fetch(url + "/" + userId, options);





}

function displayUsersList(user) {
    console.log(user);
    let userId = user.id;

    let usersContainerEl = document.createElement("li");
    usersContainerEl.classList.add("todo-item-container", "d-flex", "flex-column");
    usersContainerEl.id = userId;
    usersListContainerEl.appendChild(usersContainerEl);

    let userName = document.createElement("h1");
    userName.textContent = "UserName: " + user.name;
    usersContainerEl.append(userName);

    let emailAddress = document.createElement("p");
    emailAddress.textContent = "EmailAddress: " + user.email;
    usersContainerEl.appendChild(emailAddress);


    let companyDetails = document.createElement("span");
    companyDetails.textContent = "CompanyName: " + user.company.bs;
    usersContainerEl.appendChild(companyDetails);

    let breakEl = document.createElement("br");
    companyDetails.appendChild(breakEl);

    function editUserDetails(userId) {
        let userInputElement = document.getElementById("addUserInput");
        let userEmail = document.getElementById("addUserInputEmail").value;
        let userCompanyName = document.getElementById("addUserInputCompany").value;
        let userInputValue = userInputElement.value;
        let editedDetails = {
            name: userInputValue,
            email: userEmail,
            company: {
                bs: userCompanyName
            }
        };
        let options = {
            method: "PUT",
            headers: {
                "Content-Type": "application/json",
                Accept: "application/json",
                Authorization: "Bearer ACCESS-TOKEN"
            },
            body: JSON.stringify(editedDetails)
        };
        fetch(url + "/" + userId)
            .then((response) => {
                return response.json();
            })
            .then((jsonData) => {
                console.log(jsonData);
            })
    }
    let editButtonEl = document.createElement("button");
    editButtonEl.textContent = "Edit";
    editButtonEl.classList.add("btn", "btn-primary");
    editButtonEl.onclick = function(userId) {
        editUserDetails(userId);
    }
    companyDetails.appendChild(editButtonEl);

    let deleteButtonEl = document.createElement("button");
    deleteButtonEl.textContent = "Delete";
    deleteButtonEl.classList.add("btn", "btn-primary");
    companyDetails.appendChild(deleteButtonEl);

    deleteButtonEl.onclick = function() {
        onDeleteUser(userId);
    };
}



fetch('https://jsonplaceholder.typicode.com/users')
    .then(response => response.json())
    .then(json => {
        let data = JSON.stringify(json);
        let parsed = JSON.parse(data);
        for (let user of parsed) {
            displayUsersList(user);
        }

        function onAddUser() {
            let userInputElement = document.getElementById("addUserInput");
            let userEmail = document.getElementById("addUserInputEmail").value;
            let userCompanyName = document.getElementById("addUserInputCompany").value;
            let userInputValue = userInputElement.value;

            if (userInputValue === "") {
                alert("Enter Valid Text");
                return;
            }

            let usersCount = parsed.length + 1;

            let newUser = {
                id: usersCount,
                name: userInputValue,
                email: userEmail,
                company: {
                    bs: userCompanyName
                }
            };
            let options = {
                method: "POST",
                headers: {
                    "Content-Type": "application/json",
                    Accept: "application/json",
                    Authorization: "Bearer 572fc4bb533c9fb6f1424172bd24c44104c626b8523881750ae86558d6d29817"
                },
                body: JSON.stringify(newUser)
            };
            fetch(url, options)
                .then(function(response) {
                    return response.json();
                })
                .then(function(jsonData) {
                    console.log(jsonData);
                })
                .catch((error) => {
                    console.log(error);
                });

            displayUsersList(newUser);
            userInputElement.value = "";
            userEmail = "";
            userCompanyName = "";
        }
        addButtonEl.onclick = function() {
            onAddUser();
        };
    });